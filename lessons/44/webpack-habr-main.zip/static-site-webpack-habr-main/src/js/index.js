import "bootstrap";

document.body.style.color = "blue";
