import DoughnutChart from './DoughnutChart.vue'

export default DoughnutChart